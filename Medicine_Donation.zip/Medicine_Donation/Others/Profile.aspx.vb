﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Others_Profile
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim regid As Integer
    Dim address As String
    Private Sub btnsave_ServerClick(sender As Object, e As EventArgs) Handles btnsave.ServerClick
        address = txtadd1.Value + txtadd2.Value
        cmd = New SqlCommand("Insert into tb_profile(Reg_Id,CAddress,CPincode,CDistrict,CState)  values(" & regid & ",'" & address & "','" & txtpincode.Text & "','" & txtcity.Text & "','" & txtstate.Text & "')")
        cmd.Connection = con
        MsgBox(txtcity.Text)
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Profile Saved!!!", MsgBoxStyle.SystemModal)
        Else
            MsgBox("Error While Saving Profile!!Please Input the details One Again!!", MsgBoxStyle.SystemModal)
        End If
        con.Close()
        cleartextbox()
    End Sub
    Public Sub cleartextbox()
        txtadd1.Value = ""
        txtadd2.Value = ""
        txtcity.Text = ""
        txtpincode.Text = ""
        txtstate.Text = ""
    End Sub

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        cmd = New SqlCommand("select Reg_Id from tb_Registration where Email_Id='" & Session("Email") & "'", con)
        con.Open()
        regid = cmd.ExecuteScalar()
        con.Close()
    End Sub
End Class
