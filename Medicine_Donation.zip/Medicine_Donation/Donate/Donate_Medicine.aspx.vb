﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Donate_Medicine
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub btndonate_ServerClick(sender As Object, e As EventArgs) Handles btndonate.ServerClick

        cmd = New SqlCommand("Insert into tb_Donation(Donation_Date,Donation_Name,Medicine_Type,Medicine_Name,Email,Contact_No,Alternate_Contact_No,Address1,Address2,DState,City,Pincode,Descrip,Mfg_Date,Exp_Date) values('" & System.DateTime.Now & "','" & txtname.Text & "','" & txtmedtype.Text & "','" & txtmedname.Text & "','" & txtemail.Text & "','" & txtmobile.Text & "','" & txtaltmobile.Text & "','" & txtadd1.Value & "','" & txtadd2.Value & "','" & txtstate.Text & "','" & txtcity.Text & "','" & txtpincode.Text & "','" & txtdesc.Value & "','" & txtmfgdate.Text & "','" & txtexpdate.Text & "')")
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Insert Succesfully", MsgBoxStyle.Information)
        Else
            MsgBox("NotInsert Succesfully", MsgBoxStyle.Information)
        End If
        con.Close()
        cleartextbox()
    End Sub
    Public Sub cleartextbox()
        txtadd1.Value = ""
        txtadd2.Value = ""
        txtaltmobile.Text = ""
        txtcity.Text = ""
        txtemail.Text = ""
        txtexpdate.Text = ""
        txtmedname.Text = ""
        txtmedtype.Text = ""
        txtmfgdate.Text = ""
        txtmobile.Text = ""
        txtname.Text = ""
        txtpincode.Text = ""
        txtstate.Text = ""
    End Sub
End Class
