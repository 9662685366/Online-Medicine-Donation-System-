﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Donate_Receive_Medicine
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load

    End Sub


    Protected Sub ddmedlist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddmedlist.SelectedIndexChanged

        'Using con As SqlConnection = New SqlConnection(constr)
        '    Using cmd As SqlCommand = New SqlCommand("SELECT Descrip,Mfg_Date,Exp_Date FROM tb_Donation WHERE Medicine_Name='" & ddmedlist.SelectedItem.ToString & "'")
        '        cmd.CommandType = CommandType.Text
        '        cmd.Connection = con
        '        con.Open()
        '        Using sdr As SqlDataReader = cmd.ExecuteReader()
        '            sdr.Read()
        '            txtmfgdate.Text = sdr("Mfg_Date").ToString()
        '            txtexpdate.Text = sdr("Exp_Date").ToString()
        '            txtdesc.Value = sdr("Descrip").ToString()
        '        End Using
        '        con.Close()
        '    End Using
        'End Using

    End Sub

    Private Sub btnreceive_ServerClick(sender As Object, e As EventArgs) Handles btnreceive.ServerClick
        'Response.Redirect("../Reports/Receive_Medicinereport.aspx")

        cmd = New SqlCommand("Insert into tb_Receive_Medicine(Receiver_Name,Medicine_Type,Medicine_Name,Email,Contact_No,Alternate_Contact_No,Address1,Address2,State,City,Pincode,Description,Mfg_Date,Exp_Date,Date_Received) values('" & txtname.Text & "','" & ddmedtype.SelectedItem.ToString & "','" & ddmedlist.SelectedItem.ToString & "','" & txtemail.Text & "','" & txtmobile.Text & "','" & txtaltmobile.Text & "','" & txtadd1.Value & "','" & txtadd2.Value & "','" & txtstate.Text & "','" & txtcity.Text & "','" & txtpincode.Text & "','" & txtdesc.Value & "','" & Convert.ToDateTime(txtmfgdate.Text) & "','" & Convert.ToDateTime(txtexpdate.Text) & "','" & System.DateTime.Now & "')")
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Successfully Received Medicine!!", MsgBoxStyle.Information)
        Else
            MsgBox("Error While Processsing!!", MsgBoxStyle.Information)
        End If
        con.Close()
        cleartextbox()
    End Sub
    Public Sub cleartextbox()
        txtadd1.Value = ""
        txtadd2.Value = ""
        txtaltmobile.Text = ""
        txtcity.Text = ""
        txtemail.Text = ""
        txtexpdate.Text = ""
        ddmedtype.ClearSelection()
        ddmedlist.ClearSelection()
        txtmfgdate.Text = ""
        txtmobile.Text = ""
        txtname.Text = ""
        txtpincode.Text = ""
        txtstate.Text = ""
    End Sub
End Class
