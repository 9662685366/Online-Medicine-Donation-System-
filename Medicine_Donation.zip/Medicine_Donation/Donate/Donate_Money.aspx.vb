﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Donate_Money
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim amount As String
    Private Sub btndonate_ServerClick(sender As Object, e As EventArgs) Handles btndonate.ServerClick
        If rdb100.Checked = True Then
            amount = "100"
        ElseIf rdb1000.Checked = True Then
            amount = "1000"
        ElseIf rdb10000.Checked = True Then
            amount = "10000"
        ElseIf rdb100000.Checked = True Then
            amount = "100000"
        ElseIf rdb200000.Checked = True Then
            amount = "200000"
        ElseIf rdb50000.Checked = True Then
            amount = "50000"
        Else
            amount = txtdonateamount.Text.ToString
        End If
        Try
            cmd = New SqlCommand("Insert into tb_Donation_Money(Donation_Date,Donation_Amount,Donation_Name,Email,Contact_No,Alternate_Contact_No,Address1,Address2,DState,City,Pincode) values('" & System.DateTime.Now & "','" & amount.ToString & "','" & txtname.Text & "','" & txtemail.Text & "','" & txtmobile.Text & "','" & txtaltmobile.Text & "','" & txtadd1.Value & "','" & txtadd2.Value & "','" & txtstate.Text & "','" & txtcity.Text & "','" & txtpincode.Text & "')")
            cmd.Connection = con
            con.Open()
            If (cmd.ExecuteNonQuery()) Then
                MsgBox("Insert Succesfully", MsgBoxStyle.Information)
            Else
                MsgBox("NotInsert Succesfully", MsgBoxStyle.Information)
            End If
            con.Close()
            cleartextbox()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Public Sub cleartextbox()
        txtadd1.Value = ""
        txtadd2.Value = ""
        txtaltmobile.Text = ""
        txtcity.Text = ""
        txtemail.Text = ""
        txtdonateamount.Text = ""
        txtmobile.Text = ""
        txtname.Text = ""
        txtpincode.Text = ""
        txtstate.Text = ""
        rdb100.Checked = False
        rdb10000.Checked = False
        rdb10000.Checked = False
        rdb100000.Checked = False
        rdb200000.Checked = False
        rdb50000.Checked = False
    End Sub
End Class
