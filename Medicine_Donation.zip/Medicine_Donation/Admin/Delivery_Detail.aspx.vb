﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class Admin_Delivery_detail
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim cmd1 As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        cmd = New SqlCommand("select * from tb_Delivery", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Delivery_Detail")
        dgvdeliverydetail.DataSource = ds.Tables("Delivery_Detail")
        dgvdeliverydetail.DataBind()
    End Sub

    Private Sub btnsearch_ServerClick(sender As Object, e As EventArgs) Handles btnsearch.ServerClick
        cmd = New SqlCommand("select * from tb_Delivery where Customer_Name='" & txtsearch.Text & "'  or Mobile_No='" & txtsearch.Text & "'", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Delivery_Detail")
        dgvdeliverydetail.DataSource = ds.Tables("Delivery_Detail")
        dgvdeliverydetail.DataBind()
    End Sub
End Class
