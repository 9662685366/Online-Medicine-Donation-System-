﻿

Partial Class Admin_Admin_Index
    Inherits System.Web.UI.Page


    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load

    End Sub
End Class
