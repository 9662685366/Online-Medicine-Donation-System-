﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Web.Security

Partial Class Admin_Admin_Login
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub btnlogin_ServerClick(sender As Object, e As EventArgs) Handles btnlogin.ServerClick
        If chkremember.Checked Then
            Response.Cookies("Email").Expires = DateTime.Now.AddDays(30)
            Response.Cookies("Password").Expires = DateTime.Now.AddDays(30)
        Else
            Response.Cookies("Email").Expires = DateTime.Now.AddDays(-1)
            Response.Cookies("Password").Expires = DateTime.Now.AddDays(-1)
        End If
        Response.Cookies("Email").Value = txtemail.Text.Trim
        Response.Cookies("Password").Value = txtpwd.Text.Trim
        If txtemail.Text = "Admin@gmail.com" And txtpwd.Text = "Admin123" Then
            Response.Redirect("Admin_index.aspx")
        Else
            MsgBox("Email or Password Invalid", MsgBoxStyle.SystemModal)
        End If
        txtpwd.Text = ""
        txtemail.Text = ""
    End Sub
    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        If Not IsPostBack Then
            If ((Not (Request.Cookies("Email")) Is Nothing) _
                        AndAlso (Not (Request.Cookies("Password")) Is Nothing)) Then
                txtemail.Text = Request.Cookies("Email").Value
                txtpwd.Attributes("value") = Request.Cookies("Password").Value
            End If
        End If
    End Sub
End Class
