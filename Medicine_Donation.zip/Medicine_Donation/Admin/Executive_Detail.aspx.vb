﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Admin_Executive_Detail
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        cmd = New SqlCommand("select * from tb_Executive", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Executive")
        dgvexecutivedetail.DataSource = ds.Tables("Executive")
        dgvexecutivedetail.DataBind()
    End Sub

    Private Sub btnsearch_ServerClick(sender As Object, e As EventArgs) Handles btnsearch.ServerClick
        cmd = New SqlCommand("select * from tb_Executive where Executive_Name='" & txtsearch.Text & "' or Mobile_No='" & txtsearch.Text & "'", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Exec_detail")
        dgvexecutivedetail.DataSource = ds.Tables("Exec_detail")
        dgvexecutivedetail.DataBind()
    End Sub
End Class
