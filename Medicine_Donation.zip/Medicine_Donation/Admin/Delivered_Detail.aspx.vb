﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Admin_Delivered_Detail
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub btndelivered_ServerClick(sender As Object, e As EventArgs) Handles btndelivered.ServerClick
        cmd = New SqlCommand("Update tb_delivery set Delivery_Satus='" & ddassexec.SelectedItem.Value & "' where Delivery_Id='" & ddreceive.SelectedValue & "'", con)
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Delivered Succesfully", MsgBoxStyle.Information)
        Else
            MsgBox("Error!!!! ", MsgBoxStyle.Information)
        End If
        con.Close()
    End Sub

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        bindgrid()

    End Sub
    Private Sub bindgrid()
        Dim deliverytype As String
        deliverytype = "Drop"
        cmd = New SqlCommand("select * from tb_Delivery where Delivery_Type='" & deliverytype & "'", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Delivered_detail")
        dgvdelivered.DataSource = ds.Tables("Delivered_detail")
        dgvdelivered.DataBind()
    End Sub

End Class
