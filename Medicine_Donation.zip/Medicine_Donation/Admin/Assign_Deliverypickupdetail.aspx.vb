﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Admin_Assign_Deliverypickupdetail
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim cmd1 As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Protected Sub dgvpickupdetail_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dgvpickupdetail.SelectedIndexChanged

    End Sub

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        bindgrid()
    End Sub
    Private Sub bindgrid()
        Dim Deliverytype As String
        Deliverytype = "Pickup"
        cmd = New SqlCommand("select * from tb_Delivery Where Delivery_Type='" & Deliverytype & "'", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Pickup_Detail")
        dgvpickupdetail.DataSource = ds.Tables("Pickup_detail")
        dgvpickupdetail.DataBind()
    End Sub
End Class
