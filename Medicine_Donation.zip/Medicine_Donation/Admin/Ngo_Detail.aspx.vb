﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Admin_Ngo_Detail
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        bindgrid()
    End Sub
    Private Sub bindgrid()
        cmd = New SqlCommand("select * from tb_Ngo", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Ngo")
        dgvngodetail.DataSource = ds.Tables("Ngo")
        dgvngodetail.DataBind()
    End Sub

    Private Sub btnsearch_ServerClick(sender As Object, e As EventArgs) Handles btnsearch.ServerClick
        cmd = New SqlCommand("select * from tb_Ngo where Ngo_Name='" & txtsearch.Text & "' or License_No='" & txtsearch.Text & "'", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Ngo")
        dgvngodetail.DataSource = ds.Tables("Ngo")
        dgvngodetail.DataBind()
    End Sub


End Class
