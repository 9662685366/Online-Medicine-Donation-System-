﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Admin_Assign_Deliverypickup
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Public Donationname As String
    Public Email As String
    Public Address1 As String
    Public Addres2 As String
    Public Address As String
    Public State As String
    Public city As String
    Public pincode As String
    Public mob As String
    Public execid As Integer
    Public execname As String

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load

    End Sub

    Private Sub dddonname_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dddonname.SelectedIndexChanged
        cmd = New SqlCommand("select Donation_Name from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        Donationname = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Email from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        Email = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Address1 from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        Address1 = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Address2 from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        Addres2 = cmd.ExecuteScalar()
        con.Close()
        Address = Address1 + Addres2
        cmd = New SqlCommand("select DState from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        State = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select City from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        city = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Pincode from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        pincode = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Contact_No from tb_Donation where Donation_Name='" & dddonname.SelectedItem.Value & "'", con)
        con.Open()
        mob = cmd.ExecuteScalar()
        con.Close()
    End Sub

    Private Sub ddassign_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddassign.SelectedIndexChanged
        cmd = New SqlCommand("select Executive_Name from tb_Executive where Executive_Id='" & ddassign.SelectedValue & "'", con)
        con.Open()
        execname = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Executive_Id from tb_Executive where Executive_Id='" & ddassign.SelectedValue & "'", con)
        con.Open()
        execid = cmd.ExecuteScalar()
        con.Close()
    End Sub
    Public deliverystatus As String
    Public deliverytype As String


    Private Sub btnasssign_ServerClick(sender As Object, e As EventArgs) Handles btnasssign.ServerClick
        deliverystatus = " Delivering"
        deliverytype = "Pickup"
        cmd = New SqlCommand("Insert into tb_Delivery values('" & System.DateTime.Now & "','" & Donationname & "','" & Email & "'," & execid & ",'" & execname & "','" & Address & "','" & city & "','" & State & "','" & pincode & "','" & mob & "','" & deliverystatus & "','" & deliverytype & "')", con)
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Assigned Succesfully", MsgBoxStyle.Information)
        Else
            MsgBox("Error While Assigning ", MsgBoxStyle.Information)
        End If
        con.Close()
    End Sub
End Class
