﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Executive_Executive_Register
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub btnregister_ServerClick(sender As Object, e As EventArgs) Handles btnregister.ServerClick
        cmd = New SqlCommand("Insert into tb_Executive values('" & txtname.Text & "','" & txtemail.Text & "','" & txtpass.Text & "','" & txtaddress.Text & "','" & txtdistrict.Text & "','" & txtstate.Text & "','" & txtpincode.Text & "','" & txtlicenceno.Text & "','" & dddoctype.SelectedItem.ToString & "','" & txtdocno.Text & "','" & txtmobile.Text & "')")
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Insert Succesfully", MsgBoxStyle.Information)
            cleartextbox()
        Else
            MsgBox("NotInsert Succesfully", MsgBoxStyle.Information)
        End If
        con.Close()
    End Sub
    Public Sub cleartextbox()
        txtpass.Text = ""
        txtname.Text = ""
        txtmobile.Text = ""
        txtcpass.Text = ""
        txtemail.Text = ""
        dddoctype.Text = ""
        txtaddress.Text = ""
        txtdistrict.Text = ""
        txtdocno.Text = ""
        txtlicenceno.Text = ""
        txtpincode.Text = ""
        txtstate.Text = ""
    End Sub
End Class

