﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Admin_Assign_Deliverydrop
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Public receivename As String
    Public Email As String
    Public Address1 As String
    Public Addres2 As String
    Public Address As String
    Public State As String
    Public city As String
    Public pincode As String
    Public mob As String
    Public execid As Integer
    Public execname As String
    Public deliverystatus As String
    Public deliverytype As String

    Private Sub ddreceive_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddreceive.SelectedIndexChanged
        'Try
        '    Using cmd As SqlCommand = New SqlCommand("SELECT Receiver_Name,Email,Address1,Address2,State,City,Pincode,Contact_No FROM tb_Receive_Medicine WHERE Receive_Id='" & ddreceive.SelectedValue & "'", con)
        '        cmd.CommandType = CommandType.Text
        '        cmd.Connection = con
        '        con.Open()
        '        Using sdr As SqlDataReader = cmd.ExecuteReader()
        '            sdr.Read()
        '            receivename = sdr("Receiver_Name")
        '            Email = sdr("Email")
        '            Address1 = sdr("Address1")
        '            Addres2 = sdr("Address2")
        '            State = sdr("State")
        '            city = sdr("City")
        '            pincode = sdr("Pincode")
        '            mob = sdr("Contact_No")
        '            Address = Address1 + Addres2
        '            sdr.Close()
        '        End Using
        '    End Using
        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'Finally
        '    con.Close()
        '    con.Dispose()
        'End Try
        cmd = New SqlCommand("select Receiver_Name from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        receivename = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Email from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        Email = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Address1 from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        Address1 = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Address2 from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        Addres2 = cmd.ExecuteScalar()
        con.Close()
        Address = Address1 + Addres2
        cmd = New SqlCommand("select State from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        State = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select City from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        city = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Pincode from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        pincode = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Contact_No from tb_Receive_Medicine where Receive_Id='" & ddreceive.SelectedValue & "'", con)
        con.Open()
        mob = cmd.ExecuteScalar()
        con.Close()
    End Sub

    Private Sub ddassexec_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddassexec.SelectedIndexChanged
        'Try
        '    Using cmd As SqlCommand = New SqlCommand("SELECT Executive_Id,Executive_Name FROM tb_Executive WHERE Executive_Id='" & ddassexec.SelectedValue & "'", con)
        '        cmd.CommandType = CommandType.Text
        '        cmd.Connection = con
        '        con.Open()
        '        Using sdr As SqlDataReader = cmd.ExecuteReader()
        '            sdr.Read()
        '            execname = sdr("Executive_Name")
        '            execid = sdr("Executive_Id")
        '            sdr.Close()
        '        End Using
        '    End Using
        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'Finally
        '    con.Close()
        '    con.Dispose()
        'End Try
        cmd = New SqlCommand("select Executive_Name from tb_Executive where Executive_Id='" & ddassexec.SelectedValue & "'", con)
        con.Open()
        execname = cmd.ExecuteScalar()
        con.Close()
        cmd = New SqlCommand("select Executive_Id from tb_Executive where Executive_Id='" & ddassexec.SelectedValue & "'", con)
        con.Open()
        execid = cmd.ExecuteScalar()
        con.Close()
    End Sub



    Private Sub btnassdrop_ServerClick(sender As Object, e As EventArgs) Handles btnassdrop.ServerClick
        deliverystatus = " Delivering"
        deliverytype = "Drop"
        cmd = New SqlCommand("Insert into tb_Delivery values('" & System.DateTime.Now & "','" & receivename & "','" & Email & "'," & execid & ",'" & execname & "','" & Address & "','" & city & "','" & State & "','" & pincode & "','" & mob & "','" & deliverystatus & "','" & deliverytype & "')", con)
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Assigned Succesfully", MsgBoxStyle.Information)
        Else
            MsgBox("Error While Assigning ", MsgBoxStyle.Information)
        End If
        con.Close()
    End Sub
End Class
