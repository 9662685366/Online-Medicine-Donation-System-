﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Admin_Admin_Register
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet


    Private Sub btnregister_ServerClick(sender As Object, e As EventArgs) Handles btnregister.ServerClick
        cmd = New SqlCommand("Insert into tb_Registration (First_Name,Last_Name,Email_Id,Mobile_No,CPassword) values('" & txtfname.Text & "','" & txtlname.Text & "','" & txtemail.Text & "','" & txtmobile.Text & "','" & txtpass.Text & "')")
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Successfully Registered!!!", MsgBoxStyle.SystemModal)
        Else
            MsgBox("Error While Registering!!Please Input the details One Again!!", MsgBoxStyle.SystemModal)
        End If
        con.Close()
        cleartextbox()
    End Sub
    Public Sub cleartextbox()
        txtpass.Text = ""
        txtfname.Text = ""
        txtlname.Text = ""
        txtmobile.Text = ""
        txtpass.Text = ""
        txtcpass.Text = ""
        txtemail.Text = ""

    End Sub


End Class
