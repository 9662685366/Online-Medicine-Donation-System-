﻿
Partial Class index
    Inherits System.Web.UI.Page

    Private Sub btndonatemedicine_ServerClick(sender As Object, e As EventArgs) Handles btndonatemedicine.ServerClick
        Response.Redirect("../Donate/Donate_Medicine.aspx")
    End Sub

    Private Sub btndonatemoney_ServerClick(sender As Object, e As EventArgs) Handles btndonatemoney.ServerClick
        Response.Redirect("../Donate/Donate_Money.aspx")
    End Sub

End Class
