﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class index
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim dr As SqlDataReader

    Private Sub btncontact_ServerClick(sender As Object, e As EventArgs) Handles btncontact.ServerClick
        Try
            cmd = New SqlCommand("Insert into tb_Contact values('" & txtcname.Text & "','" & txtcemail.Text & "','" & tamessage.Value & "','" & System.DateTime.Now & "')")
            cmd.Connection = con
            con.Open()
            If (cmd.ExecuteNonQuery()) Then
                MsgBox("Insert Succesfully", MsgBoxStyle.Information)
            Else
                MsgBox("NotInsert Succesfully", MsgBoxStyle.Information)
            End If
            con.Close()
            cleartextbox()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub cleartextbox()
        txtcname.Text = ""
        txtcemail.Text = ""
        tamessage.Value = ""
    End Sub
    Private Sub btndonatemedicine_ServerClick(sender As Object, e As EventArgs) Handles btndonatemedicine.ServerClick
        Response.Redirect("Donate/Donate_Medicine.aspx")
    End Sub

    Private Sub btndonatemoney_ServerClick(sender As Object, e As EventArgs) Handles btndonatemoney.ServerClick
        Response.Redirect("Donate/Donate_Money.aspx")
    End Sub

End Class
