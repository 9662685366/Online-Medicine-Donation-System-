﻿
Partial Class Login_Registration_Logout
    Inherits System.Web.UI.Page

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        Session.Clear()
        Response.Redirect("Login.aspx")
    End Sub
End Class
