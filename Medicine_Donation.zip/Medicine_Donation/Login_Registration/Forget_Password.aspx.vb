﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Login_Registration_Forget_Password
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub btnupdatepass_ServerClick(sender As Object, e As EventArgs) Handles btnupdatepass.ServerClick
        If txtpass.Text.Equals(txtcpass.Text) Then
            cmd = New SqlCommand("UPDATE tb_Registration set CPassword ='" & txtcpass.Text & "' where Email_Id='" & txtemail.Text & "' AND Mobile_No='" & txtmobile.Text & "'", con)
            con.Open()
            If (cmd.ExecuteNonQuery()) Then
                MsgBox("Password updated Successfully!!!!", MsgBoxStyle.OkCancel)
                Response.Redirect("Login.aspx")
            Else
                MsgBox("Verification Failed!!!!Try Again", MsgBoxStyle.OkCancel)
            End If
            txtemail.Text = ""
            txtcpass.Text = ""
            txtmobile.Text = ""
            txtpass.Text = ""
            con.Close()
        Else
            MsgBox("Password Didnt Match!!!", MsgBoxStyle.MsgBoxHelp)
        End If

    End Sub
End Class
