﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Ngo_s_Login
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim ch As Boolean = False

    Private Sub btnlogin_ServerClick(sender As Object, e As EventArgs) Handles btnlogin.ServerClick
        If chkremember.Checked Then
            Response.Cookies("Email").Expires = DateTime.Now.AddDays(30)
            Response.Cookies("Password").Expires = DateTime.Now.AddDays(30)
        Else
            Response.Cookies("Email").Expires = DateTime.Now.AddDays(-1)
            Response.Cookies("Password").Expires = DateTime.Now.AddDays(-1)
        End If
        Response.Cookies("Email").Value = txtemail.Text.Trim
        Response.Cookies("Password").Value = txtpwd.Text.Trim
        If txtemail.Text = "" Or txtpwd.Text = "" Then
            MsgBox("Either Of the value Is empty")
        Else
            cmd = New SqlCommand("Select Email_Id,Pass from tb_Ngo where Email_Id= '" & txtemail.Text & "' And Pass = '" & txtpwd.Text & "'")
            Session("Email") = txtemail.Text
            cmd.Connection = con
            con.Open()
            dr = cmd.ExecuteReader()
            While dr.Read()
                ch = True
            End While
            If ch = True Then
                Response.Redirect("../NGO/Ngo's_index.aspx")
            Else
                MsgBox("Login Unsuccessfull", MsgBoxStyle.OkOnly)
            End If
            con.Close()
        End If
        txtemail.Text = ""
        txtpwd.Text = ""
    End Sub

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        If Not IsPostBack Then
            If ((Not (Request.Cookies("Email")) Is Nothing) _
                        AndAlso (Not (Request.Cookies("Password")) Is Nothing)) Then
                txtemail.Text = Request.Cookies("Email").Value
                txtpwd.Attributes("value") = Request.Cookies("Password").Value
            End If
        End If
    End Sub
End Class
