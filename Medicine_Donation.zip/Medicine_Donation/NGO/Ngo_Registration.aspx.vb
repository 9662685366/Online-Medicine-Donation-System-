﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Ngo_Registration
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet

    Private Sub btnregister_ServerClick(sender As Object, e As EventArgs) Handles btnregister.ServerClick
        cmd = New SqlCommand("Insert into tb_Ngo values('" & System.DateTime.Today & "','" & txtname.Text & "','" & txtemail.Text & "','" & txtpass.Text & "','" & txtaddress.Value & "','" & txtcity.Text & "','" & txtstate.Text & "','" & txtzip.Text & "','" & txtlicenceno.Text & "','" & dddoctype.SelectedItem.ToString & "','" & txtdocno.Text & "','" & txtmob.Text & "','" & txtmob1.Text & "')")
        cmd.Connection = con
        con.Open()
        If (cmd.ExecuteNonQuery()) Then
            MsgBox("Insert Succesfully", MsgBoxStyle.Information)
            cleartextbox()
        Else
            MsgBox("NotInsert Succesfully", MsgBoxStyle.Information)
        End If
        con.Close()
    End Sub
    Public Sub cleartextbox()
        txtpass.Text = ""
        txtname.Text = ""
        txtmob.Text = ""
        txtcpass.Text = ""
        txtemail.Text = ""
        dddoctype.Text = ""
        txtaddress.Value = ""
        txtcity.Text = ""
        txtdocno.Text = ""
        txtlicenceno.Text = ""
        txtzip.Text = ""
        txtstate.Text = ""
    End Sub
End Class
