﻿
Partial Class NGO_ngo_Profile
    Inherits System.Web.UI.Page

End Class
