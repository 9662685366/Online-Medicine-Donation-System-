﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Executive_Executive_View
    Inherits System.Web.UI.Page
    Dim con As New SqlConnection("Server=ADMIN\SQLEXPRESS;Database=db_Medicine;User=sa;Password=600626")
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim name As String
    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        bindgrid()
        cmd = New SqlCommand("select Executive_Name from tb_Executive where Executive_Email_Id='" & Session("Email") & "'", con)
        con.Open()
        name = cmd.ExecuteScalar()
    End Sub
    Private Sub bindgrid()
        cmd = New SqlCommand("select * from tb_Delivery where Executive_Name='" & name & "'", con)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "Executive_pickup")
        dgvpickdrop.DataSource = ds.Tables("Executive_pickup")
        dgvpickdrop.DataBind()
    End Sub
End Class


