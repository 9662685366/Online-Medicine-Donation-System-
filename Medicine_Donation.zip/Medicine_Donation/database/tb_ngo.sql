create table tb_Ngo
( Ngo_Id int primary key identity(1,1),
Ngo_Created_date date NUll,
Ngo_Name varchar(30) NULL,
Email_Id varchar(40) NULL,
Pass varchar(50) NULL,
Ngo_Address varchar(200) NULL,
Ngo_District varchar(50) NULL,
Ngo_State varchar(50) NULL,
Pincode varchar(15) NULL,
License_No varchar(50) NULL,
Doc_Type varchar(50) NULL,
Doc_No varchar(50) NULL, 
);