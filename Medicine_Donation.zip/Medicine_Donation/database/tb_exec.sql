create table tb_Executive
( Executive_Id int primary key identity(1,1),
Executive_Name varchar(30) NULL,
Executive_Email_Id varchar(40) NULL,
Executive_Pass varchar(50) NULL,
Executive_Address varchar(200) NULL,
Executive_District varchar(50) NULL,
Executive_State varchar(50) NULL,
Executive_Pincode varchar(10) NULL,
Vehicle_LicenceNo varchar(30) NULL,
Doc_Type varchar(50) NULL,
Doc_No varchar(50) NULL
);