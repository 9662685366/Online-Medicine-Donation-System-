create table tb_Delivery
( Delivery_Id int primary key identity(1,1),
Order_Id int References tb_Order(Order_Id),
Delivery_Created_date date NUll,
Delivery_Parcel_Name varchar(50) NULL,
Customer_Name varchar(50) NULL,
Email_Id varchar(40) NULL,
Executive_Id int REFERENCES tb_Executive(Executive_Id),
Executive_Name varchar(50) NULL,
Pass varchar(50) NULL,
Delivery_Address varchar(200) NULL,
Delivery_District varchar(50) NULL,
Delivery_State varchar(50) NULL,
Pincode varchar(15) NULL,
Mobile_No varchar(15) NULL,
Doc_Type varchar(50) NULL,
Doc_No varchar(50) NULL, 
Delivery_Satus varchar(50) NULL
);