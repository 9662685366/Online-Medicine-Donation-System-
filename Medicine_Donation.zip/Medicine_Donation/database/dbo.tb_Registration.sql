﻿CREATE TABLE [dbo].[tb_Registration] (
    [Reg_Id]     UNIQUEIDENTIFIER          NOT NULL,
    [First_Name] VARCHAR (50) NOT NULL,
    [Last_Name]  VARCHAR (50) NOT NULL,
    [Email_Id]   VARCHAR (50) NOT NULL,
    [Mobile_No]  BIGINT       NOT NULL,
    [CPassword]  VARCHAR (30) NOT NULL
);

