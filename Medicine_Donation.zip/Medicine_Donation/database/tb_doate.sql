create table tb_DonationMed
( Donation_Id int primary key identity(100,2),
Reg_Id int REFERENCES tb_Registration(Reg_Id),
Donation_Date varchar(30) NULL,
Donation_Name varchar(30) NULL,
Medicine_Type varchar(50) NULL,
Medicine_Name varchar(200) NULL,
Email varchar(40) NULL,
Contact_No varchar(15) NULL,
Alternate_Contact_No varchar(15) NULL,
Address1 varchar(200) NULL,
Address2 varchar(200) NULL,
DState varchar(50) NULL,
City varchar(50) NULL,
Pincode varchar(15) NULL,
Descrip varchar(500) NULL, 
Mfg_Date varchar(30) NULL,
Exp_Date varchar(30) NULL
); 