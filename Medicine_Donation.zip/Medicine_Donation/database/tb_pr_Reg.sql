CREATE TABLE [dbo].[tb_Registration] (
    [Reg_Id]     int Primary key identity(100000,1),
    [First_Name] VARCHAR (50) NULL,
    [Last_Name]  VARCHAR (50) NULL,
    [Email_Id]   VARCHAR (50) NULL,
    [Mobile_No]  varchar(15)  NULL,
    [CPassword]  VARCHAR (30) NULL,
);

CREATE TABLE [dbo].[tb_Profile] (
	Profile_Id int primary key identity(100,1),
    [Reg_Id]    int  NULL REFERENCES tb_Registration(Reg_Id),
    [CAddress]  VARCHAR (250) NULL,
    [CPincode]  varchar(10)   NULL,
    [CDistrict] VARCHAR (50)  NULL,
    [CState]    VARCHAR (50)  NULL,
    
);

