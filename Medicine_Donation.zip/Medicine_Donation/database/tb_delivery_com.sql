create table tb_Delivery_Complete
( Delcomp_Id int primary key identity(1,1),
Delivery_Created_date date NUll,
Order_Id int References tb_Order(Order_Id) NULL,
Reg_Id int References tb_Registration(Reg_Id) NULL,
Delivery_Name varchar(30) NULL,
Email_Id varchar(40) NULL,
Pass varchar(50) NULL,
Delivery_Address varchar(200) NULL,
Delivery_District varchar(50) NULL,
Delivery_State varchar(50) NULL,
Pincode varchar(15) NULL,
Mobile_No varchar(15) NULL,
Doc_Type varchar(50) NULL,
Doc_No varchar(50) NULL, 
Delivery_Status varchar(50) NULL
);