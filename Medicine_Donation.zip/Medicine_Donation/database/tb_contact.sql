create table tb_Contact
( Contact_Id int primary key identity(1,1),
Contact_Name varchar(30) NULL,
Email_Id varchar(40) NULL,
Descrip varchar(500) NULL
);