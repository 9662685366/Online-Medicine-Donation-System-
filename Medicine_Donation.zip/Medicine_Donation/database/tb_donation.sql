create table tb_Donation
( Donation_Id int primary key identity(100,2),
Reg_Id int REFERENCES tb_Registration(Reg_Id),
Donation_Date date NULL,
Donation_Name varchar(30) NULL,
Medicine_Type varchar(50) NULL,
Medicine_Name varchar(200) NULL,
Mfg_Date date NULL,
Exp_Date date NULL
); 